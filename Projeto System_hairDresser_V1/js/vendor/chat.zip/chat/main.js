const express = require('express');
const app = express();
const path = require('path');
const http = require('http').createServer(app);
const io = require('socket.io')(http);
var visits = 0;

http.listen(3000);

app.get('/', function (req, res) {
    res.sendFile(path.join(__dirname, 'index.html'));
});


io.on('connect', function (socket) {
    visits++;
    io.emit('visits', visits);
    socket.on('disconnect', function () {
        console.log('User disconnected!');
        visits--;
        io.emit('visits', visits);
    });
});
